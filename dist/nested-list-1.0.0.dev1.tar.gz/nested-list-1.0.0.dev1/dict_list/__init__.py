from dict_list.quick_sort import dict_quick_sort
